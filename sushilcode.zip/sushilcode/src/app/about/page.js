import React from 'react'
import AboutPage from './AboutPage'

const About = () => {
  return (
    <div>
        <AboutPage />
    </div>
  )
}

export default About