import React from 'react'

import PunePage from './PunePage'

const page = () => {
  return (
    <div>
        <PunePage />
    </div>
  )
}

export default page