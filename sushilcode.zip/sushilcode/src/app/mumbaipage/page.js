import React from 'react'
import MumbaiPage from './MumbaiPage'

const page = () => {
  return (
    <div>
        <MumbaiPage />
    </div>
  )
}

export default page