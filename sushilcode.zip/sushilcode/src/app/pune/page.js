import React from 'react'
import PuneMainPage from './PuneMainPage'

const page = () => {
  return (
    <div>
        <PuneMainPage />
    </div>
  )
}

export default page