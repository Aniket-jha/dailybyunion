import React from 'react'
import MumbaiPages from './MumbaiPages'

const SouthsideProperty = () => {
  return (
    <div>
      <MumbaiPages />
    </div>
  )
}

export default SouthsideProperty