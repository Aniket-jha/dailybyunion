import React from 'react'
import MumbaiPages from './MumbaiPages'

const page = () => {
  return (
    <div>
        <MumbaiPages />
    </div>
  )
}

export default page