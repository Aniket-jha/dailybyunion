import React from 'react'
import MumbaiMainPage from './MumbaiMainPage'

const page = () => {
  return (
    <div>
        <MumbaiMainPage />
    </div>
  )
}

export default page